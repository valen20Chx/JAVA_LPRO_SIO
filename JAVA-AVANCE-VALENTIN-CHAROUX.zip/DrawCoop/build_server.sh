serverPath="./src/server/"

javaFiles="${serverPath}/*.java"

javac ${javaFiles} -d bin/server