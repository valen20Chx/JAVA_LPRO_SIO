// package src.client;

// import src.client.drawing.Drawing;

class Main {
    public static void main(String[] args) {
        Drawing maGrid = new Drawing();
        maGrid.loop();
    }
}