class Maillon {
    int valeur;
    Maillon suiv;

    Maillon(int v, Maillon s) {
        valeur = v;
        suiv = s;
    }
}