class Vehicule {
    
};